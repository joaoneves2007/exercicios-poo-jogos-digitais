public abstract class NPC
{
    public string Nome { get; set; }

    public NPC(string nome)
    {
        Nome = nome;
    }

    public abstract void Mover();
    public abstract void Interagir();
}
