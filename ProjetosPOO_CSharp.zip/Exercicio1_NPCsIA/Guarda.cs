public class Guarda : NPC
{
    public Guarda(string nome) : base(nome) {}

    public override void Mover()
    {
        Console.WriteLine($"{Nome} está patrulhando a área.");
    }

    public override void Interagir()
    {
        Console.WriteLine($"{Nome} diz: Tudo tranquilo por aqui.");
    }
}
