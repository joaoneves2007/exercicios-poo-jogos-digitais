public class Vilao : NPC
{
    public Vilao(string nome) : base(nome) {}

    public override void Mover()
    {
        Console.WriteLine($"{Nome} está perseguindo o jogador!");
    }

    public override void Interagir()
    {
        Console.WriteLine($"{Nome} ataca o jogador!");
    }
}
