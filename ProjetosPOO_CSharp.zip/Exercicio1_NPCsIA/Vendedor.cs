public class Vendedor : NPC
{
    public Vendedor(string nome) : base(nome) {}

    public override void Mover()
    {
        Console.WriteLine($"{Nome} está andando pela loja.");
    }

    public override void Interagir()
    {
        Console.WriteLine($"{Nome} diz: Olá, quer comprar algo?");
    }
}
