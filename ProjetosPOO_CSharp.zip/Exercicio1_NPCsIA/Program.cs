using System;

class Program
{
    static void Main(string[] args)
    {
        NPC vendedor = new Vendedor("Carlos");
        NPC guarda = new Guarda("Roberto");
        NPC vilao = new Vilao("Sombrio");

        vendedor.Mover();
        vendedor.Interagir();

        guarda.Mover();
        guarda.Interagir();

        vilao.Mover();
        vilao.Interagir();
    }
}
