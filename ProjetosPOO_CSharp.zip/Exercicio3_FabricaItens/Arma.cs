public class Arma : Item
{
    public Arma()
    {
        Nome = "Espada Mística";
    }

    public override void AplicarEfeito()
    {
        Console.WriteLine($"{Nome} equipada. Ataque aumentado!");
    }
}
