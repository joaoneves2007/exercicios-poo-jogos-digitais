using System;

public class ItemFactory
{
    private static Random random = new Random();

    public static Item CriarItemAleatorio()
    {
        int tipo = random.Next(3);

        return tipo switch
        {
            0 => new Arma(),
            1 => new Pocao(),
            2 => new Armadura(),
            _ => throw new Exception("Tipo de item desconhecido")
        };
    }
}
