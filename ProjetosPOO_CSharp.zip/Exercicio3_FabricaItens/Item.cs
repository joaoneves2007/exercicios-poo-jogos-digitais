public abstract class Item
{
    public string Nome { get; set; }
    public abstract void AplicarEfeito();
}
