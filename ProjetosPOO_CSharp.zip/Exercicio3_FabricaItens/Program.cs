using System;

class Program
{
    static void Main(string[] args)
    {
        for (int i = 0; i < 5; i++)
        {
            Item item = ItemFactory.CriarItemAleatorio();
            Console.WriteLine($"Item gerado: {item.Nome}");
            item.AplicarEfeito();
            Console.WriteLine();
        }
    }
}
