public class Armadura : Item
{
    public Armadura()
    {
        Nome = "Armadura de Ferro";
    }

    public override void AplicarEfeito()
    {
        Console.WriteLine($"{Nome} equipada. Defesa aumentada!");
    }
}
