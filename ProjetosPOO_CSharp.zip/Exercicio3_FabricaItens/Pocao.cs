public class Pocao : Item
{
    public Pocao()
    {
        Nome = "Poção de Vida";
    }

    public override void AplicarEfeito()
    {
        Console.WriteLine($"{Nome} usada. Vida recuperada!");
    }
}
