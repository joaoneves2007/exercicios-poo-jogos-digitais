public interface IAtacante
{
    void Atacar(Inimigo inimigo);
}
