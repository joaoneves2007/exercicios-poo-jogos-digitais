public class Guerreiro : IAtacante
{
    public void Atacar(Inimigo inimigo)
    {
        Console.WriteLine("Guerreiro ataca com espada!");
        inimigo.ReceberDano(20);
    }
}
