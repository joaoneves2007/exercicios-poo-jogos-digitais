public class Mago : IAtacante
{
    public void Atacar(Inimigo inimigo)
    {
        Console.WriteLine("Mago lança uma bola de fogo!");
        inimigo.ReceberDano(25);
    }
}
