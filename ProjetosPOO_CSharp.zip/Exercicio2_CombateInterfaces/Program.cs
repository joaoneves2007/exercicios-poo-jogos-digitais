using System;

class Program
{
    static void Main(string[] args)
    {
        Inimigo inimigo = new Inimigo();

        IAtacante guerreiro = new Guerreiro();
        IAtacante mago = new Mago();
        IAtacante arqueiro = new Arqueiro();

        guerreiro.Atacar(inimigo);
        mago.Atacar(inimigo);
        arqueiro.Atacar(inimigo);
    }
}
