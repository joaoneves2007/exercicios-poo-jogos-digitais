public class Arqueiro : IAtacante
{
    public void Atacar(Inimigo inimigo)
    {
        Console.WriteLine("Arqueiro dispara uma flecha!");
        inimigo.ReceberDano(15);
    }
}
