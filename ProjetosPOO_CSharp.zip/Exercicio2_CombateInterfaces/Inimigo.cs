public class Inimigo
{
    public int Vida { get; private set; } = 100;

    public void ReceberDano(int dano)
    {
        Vida -= dano;
        Console.WriteLine($"Inimigo recebeu {dano} de dano. Vida restante: {Vida}");
    }
}
